import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Bookclass } from 'model/bookclass';
import { Observable } from 'rxjs';
import { BookServiceService } from 'service/book-service.service';

@Component({
  selector: 'app-booklist',
  templateUrl: './booklist.component.html',
  styleUrls: ['./booklist.component.css']
})
export class BooklistComponent implements OnInit {
  book: any;

  constructor(private bookservice:BookServiceService) { }
  
  ngOnInit() {
      this.bookservice.findAll().subscribe(data=>{
        this.book=data;
        console.log(data)
      })
  }
  
  }   
   

    

