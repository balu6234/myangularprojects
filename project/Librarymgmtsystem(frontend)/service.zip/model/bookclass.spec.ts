import { Bookclass } from './bookclass';

describe('Bookclass', () => {
  it('should create an instance', () => {
    expect(new Bookclass()).toBeTruthy();
  });
});
