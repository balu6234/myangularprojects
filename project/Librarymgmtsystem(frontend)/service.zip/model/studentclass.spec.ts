import { Studentclass } from './studentclass';

describe('Studentclass', () => {
  it('should create an instance', () => {
    expect(new Studentclass()).toBeTruthy();
  });
});
