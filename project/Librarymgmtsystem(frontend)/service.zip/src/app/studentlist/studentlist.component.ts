import { Component, OnInit } from '@angular/core';
import { StudentServiceService } from 'service/student-service.service';

@Component({
  selector: 'app-studentlist',
  templateUrl: './studentlist.component.html',
  styleUrls: ['./studentlist.component.css']
})
export class StudentlistComponent implements OnInit {
  student:any;

  constructor(private studentservice:StudentServiceService) { }
  ngOnInit() {
    this.studentservice.getAll().subscribe(data=>{
      this.student=data;
    })
  }
  

  } 


