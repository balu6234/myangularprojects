import { HttpClient,HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import {  Observable } from 'rxjs';
import { Bookclass } from 'model/bookclass';
@Injectable({
  providedIn: 'root'
})
export class BookServiceService {
  private addUrl:string;
 // private putUrl:string;
  private getUrl: string;
 // private deleteUrl:string;

  constructor(private http:HttpClient) {
    this.addUrl="http://localhost:8080/book";
   // this.putUrl="http://localhost:8080/book/update/{id}";
   // this.deleteUrl="http://localhost:8080/delete/{id}";
    this.getUrl="http://localhost:8080/getbooks";
   }
   public save(book:Bookclass)
   {
     return this.http.post<Bookclass>(this.addUrl,book);
   }
   public findAll():Observable<Bookclass[]>
   {
    return this.http.get<Bookclass[]>(this.getUrl);
   }
  /* public updateBook(id:number,book:Bookclass):Observable<Bookclass>{
    return this.http.put<Bookclass>('(this.putUrl)/{id}',book);
   }
   public deleteBook(id:number):Observable<Bookclass>{
    return this.http.delete<Bookclass>('(this.deleteUrl),/{id}');
   }*/
}
