export class Bookclass {
    id!: number;
    name!: string;
    price!: string;
    author!: string;
    publication!: string;
}
