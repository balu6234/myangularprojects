export class Studentclass {
    id!:number;
    name!: string;
    address!: string;
    age!:number;
    active!: boolean;
}
