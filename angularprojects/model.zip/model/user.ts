export class User {
    id!: string;
    name!: string;
    address!: string;
}
